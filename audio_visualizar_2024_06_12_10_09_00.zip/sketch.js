let mic, fft;

function setup() {
  createCanvas(600, 400);
  noFill();

  // Create an audio input
  mic = new p5.AudioIn();
  mic.start();

  // Create an FFT analyzer
  fft = new p5.FFT();
  fft.setInput(mic);
}

function draw() {
  background(0);

  // Get the frequency spectrum
  let spectrum = fft.analyze();

  // Draw the frequency spectrum as a series of lines
  stroke(255);
  for (let i = 0; i < spectrum.length; i++) {
    let x = map(i, 0, spectrum.length, 0, width);
    let h = -height + map(spectrum[i], 0, 255, height, 0);
    line(x, height, x, h);
  }

  // Draw a waveform
  let waveform = fft.waveform();
  stroke(0, 255, 0);
  beginShape();
  for (let i = 0; i < waveform.length; i++) {
    let x = map(i, 0, waveform.length, 0, width);
    let y = map(waveform[i], -1, 1, 0, height);
    vertex(x, y);
  }
  endShape();
}
