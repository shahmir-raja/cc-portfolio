let points = [];
let highlightedIndex = -1;

function setup() {
  createCanvas(800, 400);
  generateData(50); // Generate 50 random data points
}

function draw() {
  background(255);

  // Draw the scatter plot
  for (let i = 0; i < points.length; i++) {
    let point = points[i];
    if (i === highlightedIndex) {
      fill(255, 0, 0); // Highlighted point color
      ellipse(point.x, point.y, 12, 12); // Highlighted point size
    } else {
      fill(100, 150, 255); // Default point color
      ellipse(point.x, point.y, 8, 8); // Default point size
    }
  }

  // Display tooltip
  if (highlightedIndex !== -1) {
    let point = points[highlightedIndex];
    fill(0);
    textSize(16);
    textAlign(CENTER, BOTTOM);
    text(`(${point.x}, ${point.y})`, mouseX, mouseY - 10);
  }
}

function generateData(numPoints) {
  for (let i = 0; i < numPoints; i++) {
    let x = random(width);
    let y = random(height);
    points.push({ x, y });
  }
}

function mouseMoved() {
  // Check if the mouse is over any point
  highlightedIndex = -1;
  for (let i = 0; i < points.length; i++) {
    let d = dist(mouseX, mouseY, points[i].x, points[i].y);
    if (d < 6) { // Adjust the size of the hover area here
      highlightedIndex = i;
      break;
    }
  }
}
