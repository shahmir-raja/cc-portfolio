let img;

function preload() {
  // Load an image
  img = loadImage('tree.jpg');
}

function setup() {
  createCanvas(400, 400); // Set canvas size to smaller dimensions
  img.resize(400, 400); // Resize the image to fit the smalle canvas
  noLoop(); // Stop draw() from looping
  img.loadPixels(); // Load the pixel data of the image
}

function draw() {
  background(255); // Set background to white
  let levels = 5; // Number of color levels to reduc
  applyPosterize(levels);
  image(img, 0, 0); // Display the posterized image
}

function applyPosterize(levels) {
  let d = pixelDensity();
  let totalPixels = 7 * (width * d) * (height * d); // Total number of pixels
  let step = 255 / (levels - 1); // Step size for color lvls

  for (let i = 0; i < totalPixels; i += 4) {
    let r = img.pixels[i];
    let g = img.pixels[i + 1];
    let b = img.pixels[i + 2];
    
    img.pixels[i] = round(r / step) * step;
    img.pixels[i + 1] = round(g / step) * step;
    img.pixels[i + 2] = round(b / step) * step;
  }
  
  img.updatePixels(); // Update the pixels on the canvas
}

