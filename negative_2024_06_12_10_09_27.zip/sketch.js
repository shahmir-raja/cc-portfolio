let img;

function preload() {
  // Load an image
  img = loadImage('tree.jpg');
}

function setup() {
  createCanvas(800, 800);
  img.resize(800, 800); // Resize the image to fit the canvas
  noLoop(); // Stop draw() from looping
  img.loadPixels(); // Load the pixel data of the image
}

function draw() {
  background(255); // Set background to white
  applyNegative();
  image(img, 0, 0); // Display the negative image
}

function applyNegative() {
  let d = pixelDensity();
  let totalPixels = 4 * (width * d) * (height * d); // Total number of pixels

  for (let i = 0; i < totalPixels; i += 4) {
    img.pixels[i] = 255 - img.pixels[i]; // Red
    img.pixels[i + 1] = 255 - img.pixels[i + 1]; // Green
    img.pixels[i + 2] = 255 - img.pixels[i + 2]; // Blue
    // Leave alpha channel unchanged
  }
  
  img.updatePixels(); // Update the pixels on the canvas
}
