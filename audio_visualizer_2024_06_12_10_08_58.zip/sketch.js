let mic, fft;

function setup() {
  createCanvas(600, 400);
  noFill();

  // Create an audio input
  mic = new p5.AudioIn();
  mic.start();

  // Create an FFT analyzer
  fft = new p5.FFT();
  fft.setInput(mic);
}

function draw() {
  background(0);

  // Get the frequency spectrum
  let spectrum = fft.analyze();

  // Draw the frequency spectrum as a dynamic shape
  stroke(255);
  strokeWeight(2);
  noFill();
  beginShape();
  for (let i = 0; i < spectrum.length; i++) {
    let angle = map(i, 0, spectrum.length, 0, TWO_PI);
    let r = map(spectrum[i], 0, 255, 50, 200);
    let x = width / 2 + r * cos(angle);
    let y = height / 2 + r * sin(angle);
    vertex(x, y);
  }
  endShape(CLOSE);

  // Draw a dynamic radial waveform
  let waveform = fft.waveform();
  stroke(0, 255, 0);
  strokeWeight(1);
  noFill();
  beginShape();
  for (let i = 0; i < waveform.length; i++) {
    let angle = map(i, 0, waveform.length, 0, TWO_PI);
    let r = map(waveform[i], -1, 1, 50, 200);
    let x = width / 2 + r * cos(angle);
    let y = height / 2 + r * sin(angle);
    vertex(x, y);
  }
  endShape(CLOSE);

  // Add some color and movement to the center
  noStroke();
  fill(255, 0, 0, 150);
  let size = map(spectrum[50], 0, 255, 50, 100);
  ellipse(width / 2, height / 2, size, size);
}
