function setup() {
  createCanvas(400, 400);
  background(255);
  noLoop();
  drawRoses(20);
}

function drawRoses(numRoses) {
  for (let i = 1; i < numRoses; i++) {
    let x = random(width);
    let y = random(height);
    let size = random(60, 240);
    let numPetals = int(random(6, 24));
    drawFlower(x, y, size, numPetals);
  }
}

function drawFlower(x, y, size, numPetals) {
  push();
  translate(x, y);
  for (let i = 0; i < numPetals; i++) {
    let angle = TWO_PI / numPetals * i;
    let petalX = cos(angle) * size / 2;
    let petalY = sin(angle) * size / 2;
    drawPetal(petalX, petalY, size / 2);
  }
  drawCenter(0, 0, size / 4);
  pop();
}

function drawPetal(x, y, size) {
  push();
  translate(x, y);
  fill(255, 150, 200);
  ellipse(0, 0, size, size * 2);
  pop();
}

function drawCenter(x, y, size) {
  push();
  translate(x, y);
  fill(255, 200, 0);
  ellipse(0, 0, size, size);
  pop();
}

