function setup() {
  createCanvas(400, 400);
  background(255);
}

function draw() {
  if (mouseIsPressed) {
    drawFlower(mouseX, mouseY, 40, 10);
  }
}

function drawFlower(x, y, size, numPetals) {
  push();
  translate(x, y);
  for (let i = 0; i < numPetals; i++) {
    let angle = TWO_PI / numPetals * i;
    let petalX = cos(angle) * size / 2;
    let petalY = sin(angle) * size / 2;
    drawPetal(petalX, petalY, size / 2);
  }
  drawCenter(0, 0, size / 4);
  pop();
}

function drawPetal(x, y, size) {
  push();
  translate(x, y);
  fill(200, 150, 200);
  ellipse(0, 0, size, size * 2);
  pop();
}

function drawCenter(x, y, size) {
  push();
  translate(x, y);
  fill(255, 200, 0);
  ellipse(0, 0, size, size);
  pop();
}
