function setup() {
  createCanvas(400, 400);
  noLoop();
}


function draw() {
  background(255);
  
  
  let values = [486, 37, 45, 58, 63];
  let colors = [color(265, 0, 0), color(0, 255, 0), color(55, 0, 255), color(255, 255, 0), color(0, 300, 255)];
  
  
  let total = values.reduce((acc, val) => acc + val, 0);
  
  // Variables for pie chart
  let angleStart = 0;
  let diameter = min(width, height) * 0.75;
  
  for (let i = 0; i < values.length; i++) {
    let angleEnd = angleStart + (values[i] / total) * TWO_PI;
    fill(colors[i]);
    arc(width / 2, height / 2, diameter, diameter, angleStart, angleEnd, PIE);
    angleStart = angleEnd;
  }
}