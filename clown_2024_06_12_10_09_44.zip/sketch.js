function setup() {
  createCanvas(400, 400);
  background(255);


  // Head
  fill(255, 204, 153);
  ellipse(200, 200, 200, 250);


  // Eyes
  fill(255);
  ellipse(160, 170, 50, 30);
  ellipse(240, 170, 50, 30);
  
  fill(0);
  ellipse(160, 170, 20, 20);
  ellipse(240, 170, 20, 20);
  
  // Nose
  fill(255, 0, 0);
  ellipse(200, 210, 40, 40);
  
  // Mouth
  fill(255, 0, 0);
  arc(200, 250, 80, 50, 0, PI);


  // Hat
  fill(0, 102, 204);
  triangle(150, 70, 250, 70, 200, 30);
  
  fill(255, 204, 0);
  ellipse(200, 70, 20, 20);


  // Hair
  fill(255, 0, 0);
  ellipse(110, 170, 70, 70);
  ellipse(290, 170, 70, 70);
  ellipse(130, 100, 70, 70);
  ellipse(270, 100, 70, 70);
}


function draw() {
  // No continuous drawing needed
}
