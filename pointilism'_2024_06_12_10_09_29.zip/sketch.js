let img;

function preload() {
  // Load an image
  img = loadImage('tree.jpg');
}

function setup() {
  createCanvas(800, 800);
  img.resize(400, 400); // Resize the image to a smaller size
  noLoop(); // Stop draw() from looping
  img.loadPixels(); // Load the pixel data of the image
}

function draw() {
  background(255); // Set background to white
  for (let i = 0; i < 50000; i++) { // Increase the number of points
    drawPointillism();
  }
}

function drawPointillism() {
  // Choose a random position within the smaller image area
  let x = floor(random(400));
  let y = floor(random(400));
  
  // Get the color from the image at that position
  let c = img.get(x, y);
  
  // Draw a smaller circle with that color, scaled to fit the smaller image area
  noStroke();
  fill(c);
  ellipse(x * 2, y * 2, 3, 3); // Smaller point size for denser effect
}