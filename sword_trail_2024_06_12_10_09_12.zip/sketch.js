function setup() {
  createCanvas(400, 400);
  background(255);
}

function draw() {
  if (mouseIsPressed) {
    drawSword(mouseX, mouseY, 40);
  }
}

function drawSword(x, y, size) {
  push();
  translate(x, y);
  
  // Draw handle
  fill(139, 69, 19); // Brown color for handle
  rect(-size / 8, size / 4, size / 4, size / 2);
  
  // Draw guard
  fill(211, 211, 211); // Light gray color for guard
  rect(-size / 2, size / 4, size, size / 8);
  
  // Draw blade
  fill(192, 192, 192); // Silver color for blade
  beginShape();
  vertex(-size / 16, size / 4);
  vertex(size / 16, size / 4);
  vertex(size / 8, -size * 1.5);
  vertex(-size / 8, -size * 1.5);
  endShape(CLOSE);
  
  pop();
}
