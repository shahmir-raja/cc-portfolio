let faceColor, eyeColor, cheekColor;

function setup() {
  createCanvas(500, 500);
  angleMode(DEGREES);
  ellipseMode(CENTER);
  faceColor = select('#faceColor');
  eyeColor = select('#eyeColor');
  cheekColor = select('#cheekColor');
}

function draw() {
  background(245);
  
  drawHead();
  drawCheeks();
  drawEyes();
  drawNose();
  drawMouth();
  drawEars();
}

function drawHead() {
  fill(faceColor.value());
  noStroke();
  ellipse(250, 250, 220, 180); // Top of head
  ellipse(250, 300, 230, 170); // Bottom of head
}

function drawCheeks() {
  push();
  fill(cheekColor.value());
  stroke(0);
  translate(340, 315);
  rotate(20);
  ellipse(0, 0, 45, 60); // right cheek
  pop();
  
  push();
  fill(cheekColor.value());
  stroke(0);
  translate(160, 315);
  rotate(-20);
  ellipse(0, 0, 45, 60); // left cheek
  pop();
}

function drawEyes() {
  // black of eye
  fill(eyeColor.value());
  ellipse(310, 250, 40, 40); // right eye
  ellipse(190, 250, 40, 40); // left eye
  
  // white of eye
  fill(255);
  stroke(0);
  ellipse(305, 245, 20, 20); // right eye
  ellipse(195, 245, 20, 20); // left eye
}

function drawNose() {
  fill(0);
  ellipse(250, 270, 10, 5);
}

function drawMouth() {
  stroke(0);
  strokeWeight(3);
  noFill();
  bezier(250, 300, 270, 310, 280, 315, 290, 300); // right side
  bezier(250, 300, 230, 310, 220, 315, 210, 300); // left side
}

function drawEars() {
  push();
  fill(faceColor.value());
  noStroke();
  translate(170, 110);
  rotate(-35);
  ellipse(-40, 0, 50, 150); // Left Ear
  pop();
  
  push();
  fill(faceColor.value());
  noStroke();
  translate(290, 50);
  rotate(35);
  ellipse(110, 20, 50, 150); // Right Ear
  pop();
}

