function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(255);
  let rows = 10;
  let cols = 10;
  let w = width / cols;
  let h = height / rows;
  
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      if ((i + j) % 2 == 0) {
        fill(100, 150, 255);
      } else {
        fill(255, 150, 100);
      }
      rect(i * w, j * h, w, h);
    }
  }
}
