function setup() {
  createCanvas(400, 400);
  background(220);
  
  // Body
  fill(0, 200, 0);
  rect(150, 100, 100, 200);
  
  // Head
  rect(150, 40, 100, 100);
  
  // Eyes
  fill(0);
  rect(170, 60, 20, 20);
  rect(210, 60, 20, 20);
  
  // Mouth
  rect(190, 100, 20, 40);
  rect(170, 120, 20, 20);
  rect(210, 120, 20, 20);
}

function draw() {
}
