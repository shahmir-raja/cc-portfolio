let img;

function preload() {
  // Load the image
  img = loadImage('tree.jpg'); // Make sure the file is in the sketch directory
}

function setup() {
  // Resize the image to one-third of its original size
  img.resize(img.width / 3, img.height / 3);
  
  createCanvas(img.width, img.height);
  noLoop();
}

function draw() {
  // Display the original image
  image(img, 0, 0);
  
  // Apply a green tint varying from left to right
  loadPixels();
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      let index = (x + y * width) * 4;
      let r = pixels[index];
      let g = pixels[index + 1];
      let b = pixels[index + 2];
      
      // Increase the green channel based on the horizontal position
      let greenMultiplier = map(x, 0, width, 0.5, 1.5);
      
      pixels[index] = r * 0.5;
      pixels[index + 1] = g * greenMultiplier;
      pixels[index + 2] = b * 0.5;
    }
  }
  updatePixels();
}
