// Define variables
let colors = ['#ff007f', '#00ff7f', '#7f00ff']; // Array of neon colors
let lights = []; // Array to store the lights
let pulseSpeed = 0.05; // Speed of the pulsating effect
let neonTexts = ["Welcome to", "Metaverse Age Training Institute"]; // Texts to alternate
let currentTextIndex = 0; // Index of the current text
let glowStrength = 15; // Initial glow strength
let bgBrightness = 3; // Background brightness
let lastMouseX, lastMouseY; // Variables to track mouse position

// Background setup
let font;
let soundFile;
let amplitude;

function preload() {
  font = loadFont('ethnocentric rg.otf');
  soundFile = loadSound('lofi.mpeg'); // Load your music file
}

function setup() {
  createCanvas(800, 400); // Canvas size
  colorMode(HSB, 360, 100, 100, 100);
  textFont(font);
  textAlign(CENTER, CENTER);
  textSize(22); // Text size

  amplitude = new p5.Amplitude(); // Create a new Amplitude object

  // Create neon lights covering the entire canvas
  for (let x = 0; x < width; x += 40) {
    for (let y = 0; y < height; y += 40) {
      let size = random(5, 20); // Random size
      let speed = random(1, 3); // Random speed
      let color = random(colors); // Random color
      let direction = random(TWO_PI); // Random direction
      lights.push(new NeonLight(x, y, size, speed, color, direction)); // Create a new neon light object and add it to the array
    }
  }

  // Set initial text
  neonText = neonTexts[currentTextIndex];

  // Start playing the music and loop it
  soundFile.loop();
}

function draw() {
  // Get the amplitude level of the music
  let level = amplitude.getLevel();
  let glowColor = color(332, 58, 91, 100);
  // Adjust glow strength and background brightness based on music amplitude
  glowStrength = map(level, 0, 1, 15, 100);
  bgBrightness = map(level, 0, 2, 10, 500);

  // Background drawing
  background(0, bgBrightness); // Lighter black background

  // Update and display each neon light
  for (let light of lights) {
    light.update();
    light.display();
  }

  // Text drawing
  let textColor;
  if (mouseIsPressed) { // Change text color when mouse is pressed
    glowColor = color(255, 50, 50);// Change to a different color
    // Change neon lights color
    for (let light of lights) {
      light.color = random(colors);
    }
  }
  textNeon(neonText, width / 2, height / 2, glowColor); // Display the neon text
}
function mouseMoved() {
  // Change the color of the neon lights when the mouse is moved
  for (let light of lights) {
    light.color = color(random(360), 100, 100);
  }
}


function keyPressed() {
  // Toggle the pulsating effect on and off using keyboard keys
    if (key === 'r' || key === 'R') {
    neonText = 'Bath Spa University'; // Change the text when 'R' key is pressed
  }
}
// NeonLight class
class NeonLight {
  constructor(x, y, size, speed, color, direction) {
    this.x = x; // x position
    this.y = y; // y position
    this.size = size; // Size of the light
    this.speed = speed; // Movement speed
    this.color = color; // Color of the light
    this.direction = direction; // Movement direction
    this.initialSize = size; // Initial size of the light for pulsating effect
  }

  // Update the position and size of the light
  update() {
    // Move the light based on its direction
    this.x += cos(this.direction) * this.speed;
    this.y += sin(this.direction) * this.speed;

    // Bounce off the edges of the canvas
    if (this.x < 0 || this.x > width) {
      this.direction = PI - this.direction;
    }
    if (this.y < 0 || this.y > height) {
      this.direction = -this.direction;
    }

    // Pulsating effect
    this.size = this.initialSize + sin(frameCount * pulseSpeed) * 5;
  }

  // Display the light as a heart shape
  display() {
    noStroke();
    // Set the fill color with transparency
    fill(red(this.color), green(this.color), blue(this.color), 100);
    // Draw the light as a heart shape
    beginShape();
    vertex(this.x, this.y + this.size / 2);
    bezierVertex(this.x, this.y - this.size / 2, this.x + this.size / 2, this.y - this.size / 2, this.x, this.y + this.size / 2);
    bezierVertex(this.x - this.size / 2, this.y - this.size / 2, this.x, this.y - this.size / 2, this.x, this.y + this.size / 2);
    endShape(CLOSE);
  }
}

// Text neon effect
function textNeon(glowText, x, y, glowColor) {
  glow(glowColor, glowStrength);
  text(glowText, x + cos(frameCount * 0.1) * 5, y + sin(frameCount * 0.1) * 5); // Add subtle oscillating movement to text
  text(glowText, x + cos(frameCount * 0.1 + PI) * 5, y + sin(frameCount * 0.1 + PI) * 5); // Add subtle oscillating movement to text
  text(glowText, x, y);
  text(glowText, x, y);
  text(glowText, x, y);
  glow(glowColor, glowStrength / 2 + sin(frameCount * 0.05) * 10); // Pulsating glow effect with changing strength
  text(glowText, x, y);
  text(glowText, x, y);
  glow(glowColor, glowStrength / 3 + sin(frameCount * 0.05) * 5); // Pulsating glow effect with changing strength
  text(glowText, x, y);
  text(glowText, x, y);
  text(glowText, x, y);
}

// Glow effect
function glow(glowColor, blurriness) {
  drawingContext.shadowBlur = blurriness;
  drawingContext.shadowColor = glowColor;
}

// Timer to alternate texts
setInterval(function() {
  currentTextIndex = (currentTextIndex + 1) % 2; // Toggle between 0 and 1
  neonText = neonTexts[currentTextIndex]; // Set current text
}, 1500); // Change text every 1.5 seconds (1500 milliseconds)