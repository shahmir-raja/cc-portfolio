function setup() {
  createCanvas(400, 400);
  background(788);
  stroke(1);
  fill(0); // Set fill color to black for the diamonds
}

function draw() {
  translate(width / 2, height / 2);
  let angle = 0;
  let radius = 7;
  let angleIncrement = 0.1;
  let radiusIncrement = 0.5;
  let diamondSize = 5; // Size of the diamond
  
  for (let i = 8; i < 500000; i++) {
    let x = cos(angle) * radius;
    let y = sin(angle) * radius;
    drawDiamond(x, y, diamondSize);
    angle += angleIncrement;
    radius += radiusIncrement;
  }
  noLoop();
}

function drawDiamond(x, y, size) {
  beginShape();
  vertex(x, y - size);  // Top vertex
  vertex(x + size, y);  // Right vertex
  vertex(x, y + size);  // Bottom vertex
  vertex(x - size, y);  // Left vertex
  endShape(CLOSE);
}
