function setup() {
  createCanvas(400, 400);
  noFill();
}

function draw() {
  background(255);
  let numCircles = 20;
  let maxRadius = 200;
  
  for (let i = 0; i < numCircles; i++) {
    let radius = (i / numCircles) * maxRadius;
    stroke(i * 10, 100, 255 - i * 10);
    ellipse(width / 2, height / 2, radius * 2, radius * 2);
  }
}
